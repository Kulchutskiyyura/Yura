import pygame
from random import randint
import time
import  threading  
from os import path
pygame.init()
screen = pygame.display.set_mode((500,500))
print(screen)
pygame.display.set_caption("Dudle Jump")
clock = pygame.time.Clock()
play=True
size_of_rectangle_move=0
x_rectangle=0
y_rectangle=0
dudle_jump_img = pygame.image.load('D:/dudle_jm_img/dudle3.png')
dudle_jump_img.set_colorkey((255, 255, 255))
monster1 = pygame.image.load('D:/dudle_jm_img/monster.png')
monster1.set_colorkey((255, 255, 255))
monster2 = pygame.image.load('D:/dudle_jm_img/monster4.png')
monster2.set_colorkey((255, 255, 255))
monster3 = pygame.image.load('D:/dudle_jm_img/monster3.png')
monster3.set_colorkey((255, 255, 255))
GREEN=  (0, 255, 0)
GRAY = (125, 125, 0)
LIGHT_BLUE = (64, 128, 255)
BLACK = (0, 0, 0)
ORANGE = (255, 150, 100)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
WHITE=(255,255,255)
last_y=y_rectangle
last_x=x_rectangle
#snd_dir = path.join("D:/SOUND", 'snd')
jump_sound = pygame.mixer.Sound(path.join("D:/SOUND", 'Jump4.WAV'))
shoot_sound=pygame.mixer.Sound(path.join("D:/SOUND", 'Hit_Hurt5.WAV'))
jump_sound_sp=pygame.mixer.Sound(path.join("D:/SOUND", 'Jump7.WAV'))
monster_sound=pygame.mixer.Sound(path.join("D:/SOUND", 'monster_sound.WAV'))
def f():
        pass

class My_Thread(threading.Thread):
    def __init__(self, class_name=None,timeout=0.55):
        threading.Thread.__init__(self, name="jump timer" )
        self.class_name = class_name
        self.timeout=timeout
    def run(self):
        if type(self.class_name)==Rectangle_burn:
            t = threading.Timer(self.timeout,f)
     
            t.start()
            t.join()
            self.class_name.burn_finish=True
        elif type(self.class_name) == Bulet:
           # print("start")
            t = threading.Timer(self.timeout,f)
            
            t.start()
            t.join()
           # print("change")
            Bulet.shoot_ready=True 
        else:
            t = threading.Timer(self.timeout,f)
     
            t.start()
            t.join()
            #print("yraaaaaa")
            self.class_name.jump_mode=not self.class_name.jump_mode
            self.class_name.timer_on=False
            t = threading.Timer(self.timeout/6,f)
     
            t.start()
            t.join()
            self.class_name.fall_ready=True



class Rectangle:
    count=0
    
    def __init__(self, x_cordinat, y_cordinat,rectangle_hight=10,rectangle_width=100,color=GREEN):

        if(x_cordinat>400):
            self.x_cordinat=400
        elif(x_cordinat<0):
            self.x_cordinat=0
        else:
            self.x_cordinat=x_cordinat
        if(y_cordinat>490):
            self.y_cordinat=490
           
        elif(y_cordinat<-50):
            if type(self) == Monster:
                self.y_cordinat=y_cordinat
            else:
                self.y_cordinat=-50
        else:
            self.y_cordinat=y_cordinat
        self.color=color
        self.rectangle_hight=rectangle_hight
        self.rectangle_width=rectangle_width
        pygame.draw.rect(screen, self.color, (self.x_cordinat, self.y_cordinat, rectangle_width, rectangle_hight))
        #pygame.display.update()
        #print(screen)
        Rectangle.count+=1
    def __repr__(self):
        return (f"the left hight cordinate is({self.x_cordinat};{self.y_cordinat})")

    def change_position(self,x_cordinat, y_cordinat):
        
        if  y_cordinat>500:
            #self.__del__()
            #print("h")
            
            return 0

        self.x_cordinat=x_cordinat
        self.y_cordinat=y_cordinat
        if type(self)==Monster :  
            screen.blit(monster1,(self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))
        elif type(self)==Monster_move  :
            screen.blit(monster2,(self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))
        elif  type(self)==Monster_pursue:
            screen.blit(monster3,(self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))
        else:
            pygame.draw.rect(screen, self.color, (self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))
        #pygame.display.update()
        return 1
        
    def __del__(self):
        Rectangle.count-=1


class Rectangle_move(Rectangle):
    def __init__(self,x_cordinat, y_cordinat,horizontal_move_size,rectangle_hight=10,rectangle_width=100,color=LIGHT_BLUE):
        Rectangle.__init__(self,x_cordinat, y_cordinat,rectangle_hight,rectangle_width,color=color)
        self.horizontal_move_size=horizontal_move_size
        self.move_mode=True
    def horizontical_move(self):
        if(self.move_mode):
            if self.x_cordinat+self.horizontal_move_size<465:
                self.x_cordinat+=self.horizontal_move_size
            else:
                self.move_mode=not self.move_mode
        else:
            if self.x_cordinat-self.horizontal_move_size>0:
                self.x_cordinat-=self.horizontal_move_size
            else:
                self.move_mode=not self.move_mode

class Rectangle_disappear(Rectangle):
    def __init__(self,x_cordinat, y_cordinat,rectangle_hight=10,rectangle_width=100,color=BLACK):
        Rectangle.__init__(self,x_cordinat, y_cordinat,rectangle_hight,rectangle_width,color=color)
    def __del__(self):
         Rectangle.__del__(self)

class Rectangle_burn(Rectangle):
     def __init__(self,x_cordinat, y_cordinat,rectangle_hight=10,rectangle_width=100,color=ORANGE):
        Rectangle.__init__(self,x_cordinat, y_cordinat,rectangle_hight,rectangle_width,color=color)
        self.burn_finish=False
        self.is_active=False
        self.color=list(self.color)
     def burn(self):
        if(not self.is_active):
            self.is_active=True
            p1 = My_Thread(self,timeout=1.5)
            p1.start()

     def change_color(self):
         if self.color[1]+1.3<255:
            self.color[1]+=1.15
         if self.color[2]+1.3<255:
            self.color[2]+=1.15
     def __del__(self):
         Rectangle.__del__(self)
        
class Boost_device(Rectangle):
     def __init__(self,rectangle,boost_size,rectangle_hight=15,rectangle_width=15,color=RED):
        Rectangle.__init__(self,randint(rectangle.x_cordinat,rectangle.x_cordinat+rectangle_width), rectangle.y_cordinat-rectangle_hight,rectangle_hight,rectangle_width,color=color)
        self.boost_size=boost_size
        

list_of_rectangle=[]
list_of_static_device=[]

class Monster(Rectangle):
     def __init__(self,x_cordinat, y_cordinat,rectangle_hight=60,rectangle_width=60,color=BLACK,health_point=1,fall_speed=8):
        Rectangle.__init__(self,x_cordinat, y_cordinat,rectangle_hight,rectangle_width,color=color)
        self.health_point=health_point
        self.fall_speed=fall_speed
        self.alive=True
     def fall(self):
        self.y_cordinat+=self.fall_speed
        if  type(self)==Monster_move  :

            screen.blit(monster2,(self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))
        elif type(self)==Monster_pursue:
            screen.blit(monster3,(self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))
        else:
            screen.blit(monster1,(self.x_cordinat, self.y_cordinat, self.rectangle_width,self.rectangle_hight))

class Monster_pursue(Monster):
    pass
   
class Monster_move(Monster,Rectangle_move):
    def __init__(self,x_cordinat, y_cordinat,rectangle_hight=60,rectangle_width=60,color=BLACK,health_point=1,fall_speed=8,move_spead=1.5):
        Monster.__init__(self,x_cordinat, y_cordinat,rectangle_hight=60,rectangle_width=60,color=BLACK,health_point=1,fall_speed=8)
        self.horizontal_move_size=move_spead
        self.move_mode=True


class Person:
    def __init__(self, last_element,person_hight=80,person_width=45,jump_size=8,jump_fall=7,horizontal_move_size=10):
        self.person_hight=person_hight
        self.person_width=person_width
        #pygame.draw.rect(screen, LIGHT_BLUE , (last_element.x_cordinat, last_element.y_cordinat-person_hight, person_width, person_hight))
        screen.blit(dudle_jump_img,(last_element.x_cordinat, last_element.y_cordinat-person_hight, person_width, person_hight))
        #pygame.display.update()
        self.person_x_cordinat=last_element.x_cordinat
        self.person_y_cordinat=last_element.y_cordinat-person_hight
        self.jump_mode=False
        self.jump_size=jump_size
        self.fall_size=jump_fall
        self.timer_on=False
        self.horizontal_move_size=horizontal_move_size
        self.jump_boost=0
        self.fall_ready=True
        self.alive=True
    def chack_fall(self):
         #print("change jm to False")
         self.jump_mode=False
         self.timer_on=True
         #self.timer( 1.5)
         p1 = My_Thread(self) 
         p1.start()

         #p1.join()
    def repaint(self):
        #pygame.draw.rect(screen, LIGHT_BLUE , (self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
        #pygame.display.update()
         if type(self)!=Bulet:
                screen.blit(dudle_jump_img,(self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
    def fall(self):
        if(self.person_y_cordinat+self.jump_size>500):
            print("game over")
            return -1
        else :
            self.person_y_cordinat+=self.fall_size
            #pygame.draw.rect(screen, LIGHT_BLUE , (self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
            #pygame.display.update()
            #print("fall")
            if type(self)!=Bulet:
                
                screen.blit(dudle_jump_img,(self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
            else:
                print("fall")
            return 1
    def chack_static_device(self,list_of_static_device):
        for i in list_of_static_device:
            if self==i:
                self.jump_boost=i.boost_size

                return True
        else:
            return False
    def chack_jump(self,list_of_rectangle,fine_size):
        for i in range(len(list_of_rectangle)):
            if self==list_of_rectangle[i]:
                if type(list_of_rectangle[i])==Rectangle_disappear:
                    del list_of_rectangle[i]
                elif type(list_of_rectangle[i])==Rectangle_burn:
                    list_of_rectangle[i].burn()
                elif type(list_of_rectangle[i])==Monster or  type(list_of_rectangle[i])==Monster_move or type(list_of_rectangle[i])==Monster_pursue:
                    list_of_rectangle[i].alive=False
                self.jump_boost=0
                self.jump_mode=True
                self.fall_ready=False
                #print("change jm to True")
                self.timer_on=True
                #print("cheack jump")
                self.jump(fine_size)
                # self.timer( 1.5)
                #jump_sound.play()
                p1 = My_Thread(self)
                p1.start()
                #p1.join()
                return True  
        else:
            return False

    def jump(self,fine_size):
         #print("jump")
         if self.person_y_cordinat-self.jump_size+fine_size-self.jump_boost<0:
            self.person_y_cordinat=0
            #pygame.draw.rect(screen, LIGHT_BLUE , (self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
            #pygame.display.update()
            screen.blit(dudle_jump_img,(self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
         else:
            self.person_y_cordinat -= self.jump_size + self.jump_boost
            self.person_y_cordinat+=fine_size
            #print(f" y cordinat {self.person_y_cordinat}")
            #pygame.draw.rect(screen, LIGHT_BLUE , (self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
            #pygame.display.update()
            if type(self)!=Bulet:
                
                screen.blit(dudle_jump_img,(self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
            else:
                pass
                #print("jump")

    def __eq__(self,rectangle):
        #print("self",end="")
        #print(self.person_x_cordinat+self.person_width, self.person_y_cordinat+70)
        #print("rec",end="")
        #print(rectangle.x_cordinat+rectangle.rectangle_width,rectangle.x_cordinat,rectangle.y_cordinat+10,rectangle.y_cordinat)
        if type(rectangle)==Boost_device:
            if (self.person_x_cordinat<=rectangle.x_cordinat<=self.person_x_cordinat+self.person_width and self.person_y_cordinat<=rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight)or  \
                (self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width<=self.person_x_cordinat+self.person_width and self.person_y_cordinat<=rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight) or\
               (self.person_x_cordinat<=rectangle.x_cordinat<=self.person_x_cordinat+self.person_width and self.person_y_cordinat<=rectangle.y_cordinat+rectangle.rectangle_hight<=self.person_y_cordinat+self.person_hight)or  \
               (self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width<=self.person_x_cordinat+self.person_width and self.person_y_cordinat<=rectangle.y_cordinat+rectangle.rectangle_hight<=self.person_y_cordinat+self.person_hight):
                  #print("hit")
                  return True
            else:
               # print("no")

                return False
        elif type(rectangle)==Monster or  type(rectangle)==Monster_move  or type(rectangle)==Monster_pursue:
            #оригінал
            if (rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight-rectangle.rectangle_hight/0.2<=rectangle.y_cordinat+rectangle.rectangle_hight)or \
               (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight-rectangle.rectangle_hight/0.2<=rectangle.y_cordinat+rectangle.rectangle_hight) or \
               (rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)or  \
               (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight):
        #(rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight-rectangle.rectangle_hight<=rectangle.x_cordinat+rectangle.rectangle_width)or(rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and self.person_y_cordinat+self.person_width-rectangle.rectangle_width<=rectangle.y_cordinat+rectangle.rectangle_hight):
        #(rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)or  (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)
            #print("yes")):
            #print("yes")
                
                return True
            elif (rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+rectangle.rectangle_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)or \
               (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat-rectangle.rectangle_hight<=rectangle.y_cordinat+rectangle.rectangle_hight) or \
               (rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat<=rectangle.y_cordinat-rectangle.rectangle_hight)or  \
               (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat<=rectangle.y_cordinat+rectangle.rectangle_hight):
            #print("no")
                self.alive=False
                return False
            else: 
                return False
        else:
            if (rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight-rectangle.rectangle_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)or \
               (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight-rectangle.rectangle_hight<=rectangle.y_cordinat+rectangle.rectangle_hight) or \
               (rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)or  \
               (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight):
        #(rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight-rectangle.rectangle_hight<=rectangle.x_cordinat+rectangle.rectangle_width)or(rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and self.person_y_cordinat+self.person_width-rectangle.rectangle_width<=rectangle.y_cordinat+rectangle.rectangle_hight):
        #(rectangle.x_cordinat<=self.person_x_cordinat<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)or  (rectangle.x_cordinat<=self.person_x_cordinat+self.person_width<=rectangle.x_cordinat+rectangle.rectangle_width and rectangle.y_cordinat<=self.person_y_cordinat+self.person_hight<=rectangle.y_cordinat+rectangle.rectangle_hight)
            #print("yes")):
            #print("yes")
                return True
            else:
            #print("no")
                return False
    def horizontal_move(self,right_or_left):
        if(right_or_left):
            if(self.person_x_cordinat>475): 
                self.person_x_cordinat=-35
            else:
                self.person_x_cordinat+=self.horizontal_move_size
        else:
            if(self.person_x_cordinat<-35):
                self.person_x_cordinat=475
            else:
                self.person_x_cordinat-=self.horizontal_move_size
        if type(self)!=Bulet:
                
                screen.blit(dudle_jump_img,(self.person_x_cordinat, self.person_y_cordinat, self.person_width, self.person_hight))
        else:
            #print("hor"
            pass
        #pygame.display.update()
class Bulet(Person):
    shoot_ready=True
    def __init__(self, dudle_jump,person_hight=8,person_width=8,jump_size=6,color=RED):
         self.person_hight=person_hight
         self.person_width=person_width
         
         self.person_x_cordinat= dudle_jump.person_x_cordinat+dudle_jump.person_width/2
         self.person_y_cordinat= dudle_jump.person_y_cordinat-person_hight
         self.direction=None
         if self.person_x_cordinat>250:
              self.direction=False
         else:
              self.direction=True
         Bulet.shoot_ready=True
         self.jump_size=jump_size
         if dudle_jump.person_x_cordinat>400 or dudle_jump.person_x_cordinat<100:
             self.horizontal_move_size=6
         elif dudle_jump.person_x_cordinat>300 or dudle_jump.person_x_cordinat<200:
             self.horizontal_move_size=4
         elif dudle_jump.person_x_cordinat<300 and dudle_jump.person_x_cordinat>100:
             self.horizontal_move_size=2
         else:
            self.horizontal_move_size=0
         self.alive=True
         self.fly=False
         self.counter=0
         self.color=color
         self.jump_boost=0
         pygame.draw.rect(screen, self.color, (self.person_x_cordinat, self.person_y_cordinat, self.person_width,self.person_hight))
    def move(self):
        if self.counter>=1:
            self.horizontal_move(self.direction)
            self.counter=0
        self.jump(0)
        pygame.draw.rect(screen, self.color, (self.person_x_cordinat, self.person_y_cordinat, self.person_width,self.person_hight))
        self.counter+=1
    def chack(self):
        if self.person_y_cordinat<0 or self.person_x_cordinat<0 or self.person_x_cordinat>500 or self.person_y_cordinat>500:
            return -1
        else :
            return 1
    def horizontal_move(self,right_or_left):
        if(right_or_left):
                self.person_x_cordinat+=self.horizontal_move_size
        else:                  
                self.person_x_cordinat-=self.horizontal_move_size
        #print("hor")
    def jump(self,fine_size):               
        self.person_y_cordinat -= self.jump_size + self.jump_boost
        self.person_y_cordinat+=fine_size
        #print("jump")
    
    def shoot_pause(self):
        Bulet.shoot_ready=False
        p1 = My_Thread(self,timeout=0.2)
        p1.start()
    
        
    


screen.fill((128,128,128))    
fontObj = pygame.font.Font('freesansbold.ttf', 50)
textSurfaceObj = fontObj.render(f'Dudle Jump', True, LIGHT_BLUE, (128,   128,   128))
textRectObj = textSurfaceObj.get_rect()
textRectObj.center = (255, 220)
screen.blit(textSurfaceObj, textRectObj)
pygame.display.update()

        #print(f"jsj{self.n.q}")
while(1):
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT:
            play=False
    key=pygame.key.get_pressed()
    if  key[pygame.K_UP]:
        break

spead=60

number_of_rectangle=12
for i in range(number_of_rectangle):
    if(x_rectangle<340):
        x_rectangle= randint(x_rectangle-60,400)
    else:
        x_rectangle= randint(x_rectangle-80,400)

    y_rectangle=randint( y_rectangle+(350//number_of_rectangle), y_rectangle+(600//number_of_rectangle))
    print(x_rectangle,y_rectangle)
    o=Rectangle(x_rectangle,y_rectangle)
    list_of_rectangle.append(o)

Dudle_Jump=Person(list_of_rectangle[-1])
#print(Dudle_Jump.person_y_cordinat,end="\n\n\n")
cycle_counter=0
game_score=0
pygame.display.update()

#rectengle_counter=0
bulet_list=[]
Monster_list=[]
def show_game_over():
     fontObj = pygame.font.Font('freesansbold.ttf', 50)
     textSurfaceObj = fontObj.render(f'Game over', True, LIGHT_BLUE, (255,  255,  255))
     extRectObj = textSurfaceObj.get_rect()
     textRectObj.center = (160, 220)
     screen.blit(textSurfaceObj, textRectObj)
     pygame.display.update()
     time.sleep(2)
     
y_prev=Dudle_Jump.person_y_cordinat
monst_score=0

while play:
    y_prev=Dudle_Jump.person_y_cordinat
   # print("\n new iteration")
    if Monster_list:
        if 0< Monster_list[0].y_cordinat<500:
            monster_sound.play()
    cycle_counter+=1
    if cycle_counter==650:
        cycle_counter=0
        if number_of_rectangle>4:
            number_of_rectangle-=1
    screen.fill((255,255,255))

    fontObj = pygame.font.Font('freesansbold.ttf', 22)
    textSurfaceObj = fontObj.render(f'score : {game_score}', True, LIGHT_BLUE, (255,   255,   255))
    textRectObj = textSurfaceObj.get_rect()
    textRectObj.center = (60, 30)
    screen.blit(textSurfaceObj, textRectObj)
    #time.sleep(0.005)
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT:
            play=False
    keys=pygame.key.get_pressed()
    if not Monster_list  and Dudle_Jump.jump_boost==0  and Dudle_Jump.person_y_cordinat>40 and game_score-monst_score>30 :
        monst_score=game_score
        monster_apear=randint(1,6)
        if monster_apear==4 :
            obj=Monster_move(randint(0,400),-50)
            Monster_list.append(obj)
        elif monster_apear==3 or monster_apear==6:
            obj=Monster(randint(0,400),-50)
            Monster_list.append(obj)
        elif monster_apear==2 or monster_apear==5 :
            obj=Monster_pursue(randint(0,400),-50)
            Monster_list.append(obj)
    elif Monster_list:
        if(type(Monster_list[0])==Monster_move):
                Monster_list[0].horizontical_move()
        if  Monster_list[0].alive and Monster_list[0].y_cordinat>10:

            Dudle_Jump.chack_jump(Monster_list,size_of_rectangle_move)
            
        elif not Monster_list[0].alive and Dudle_Jump.alive:
            Monster_list[0].fall()

    #Dudle_Jump.chack_jump(list_of_rectangle)
    #if_jump=Dudle_Jump.jump_mode
    #print(f"jump mode is {Dudle_Jump.jump_mode}")
    #(f"timer is {Dudle_Jump.timer_on}")
    key=pygame.key.get_pressed()
    if  key[pygame.K_UP] and Bulet.shoot_ready :
        obj=Bulet(Dudle_Jump)
        bulet_list.insert(0,obj)
        shoot_sound.play()
        bulet_list[0].shoot_pause()
        #print("shooot")
    #print(len(bulet_list))
    size=len(bulet_list)
    if  bulet_list:
        counter=0
        i=0
        while i<(size-counter-1):
            if Monster_list:
                if bulet_list[i]==Monster_list[0]:
                    del Monster_list[0]
                    del bulet_list[i]
                    #print("beat")
                    break
            
            if bulet_list[i].chack()==-1:
                #print("del ",i)
                del bulet_list[i]
                counter+=1
                i-=1
                #continue
            bulet_list[i].move()
            i+=1

    if Dudle_Jump.timer_on==True  and Dudle_Jump.alive:
        #print("timer is on")
        #print(Dudle_Jump.jump_mode)
        if(Dudle_Jump.jump_mode==True):
           # print("jump")
            Dudle_Jump.jump(size_of_rectangle_move)
            
        else:
           pass
           # print("fall")
           #Ddle_Jump.fall()
    elif Dudle_Jump.fall_ready and Dudle_Jump.alive:
        Dudle_Jump.chack_jump(list_of_rectangle,size_of_rectangle_move)
        #print(f"jump mode is {Dudle_Jump.jump_mode} important")
        if  Dudle_Jump.jump_mode==False :
            chack=Dudle_Jump.fall()
            #screen.fill((128,128,128))
           
            if(chack==-1):
               show_game_over()
               break
              
        else:
            type_sound=Dudle_Jump.chack_static_device(list_of_static_device)
            if type_sound:
                jump_sound_sp.play()
            else:
                jump_sound.play()
    else:
        chack=Dudle_Jump.fall()
        if chack==-1:
            show_game_over()
            break
                         
               
            
    
    keys=pygame.key.get_pressed()
    if keys[pygame.K_LEFT] :
        Dudle_Jump.horizontal_move(False)
        
      
        
    if keys[pygame.K_RIGHT] :
        
         Dudle_Jump.horizontal_move(True)

    #print(f"jump mode is {Dudle_Jump.jump_mode}")
    #pygame.draw.rect(screen, LIGHT_BLUE , (Dudle_Jump.person_x_cordinat, Dudle_Jump.person_y_cordinat, Dudle_Jump.person_width, Dudle_Jump.person_hight))
    #pygame.display.update()
    
    if True:
        if 80<Dudle_Jump.person_y_cordinat<=100:
            size_of_rectangle_move=0.5
        elif 50<Dudle_Jump.person_y_cordinat<=80:
            size_of_rectangle_move=3
        elif 30<Dudle_Jump.person_y_cordinat<=50:
            size_of_rectangle_move=4
        elif 10<Dudle_Jump.person_y_cordinat<=30:
            size_of_rectangle_move=9
        elif Dudle_Jump.person_y_cordinat<=10:
            size_of_rectangle_move=12
        else:
            size_of_rectangle_move=0
        #pygame.draw.rect(screen, WHITE, (120,120, 45, 70))
        
        counter=0
        i=0
        #print(f"y={Dudle_Jump.person_y_cordinat}")
        #print(f"size={size}")
        # написати try блок для перевірки виходу за межі масиву
       # print(len(list_of_static_device))

        if Monster_list:
             if type(Monster_list[0])==Monster_pursue:
                 chack=Monster_list[0].change_position(Monster_list[0].x_cordinat,Monster_list[0].y_cordinat+size_of_rectangle_move/2)
             else:
                chack=Monster_list[0].change_position(Monster_list[0].x_cordinat,Monster_list[0].y_cordinat+size_of_rectangle_move)
                if(chack==0):
                    del Monster_list[0]

        while i<(len(list_of_static_device)-counter):
            #print(f"sizem{size_of_rectangle_move}")
            chack=list_of_static_device[i].change_position(list_of_static_device[i].x_cordinat,list_of_static_device[i].y_cordinat+size_of_rectangle_move)
            if(chack==0):
                del list_of_static_device[i]
                counter+=1
            else:
                i+=1

        i=0
        counter=0
       # print("\n")
        while i<(len(list_of_rectangle)-counter):
            try:
                if type(list_of_rectangle[i])==Rectangle_move:
                    list_of_rectangle[i].horizontical_move()
                elif type(list_of_rectangle[i])==Rectangle_burn:
                    if(list_of_rectangle[i].is_active):
                        if list_of_rectangle[i].burn_finish:
                            del list_of_rectangle[i]
                        #i+=1
                            continue
                        else :
                            list_of_rectangle[i].change_color()
               # print(f"sizem_rec{size_of_rectangle_move}")
                chack=list_of_rectangle[i].change_position(list_of_rectangle[i].x_cordinat,list_of_rectangle[i].y_cordinat+size_of_rectangle_move)
                if(chack==0):
                    del list_of_rectangle[i]
                    counter+=1
                    if  spead<140:
                        spead+=0.1*(number_of_rectangle/len(list_of_rectangle))
                else:
                    i+=1 
               
            except IndexError as l:
                print("\n\n\nindex eror\n\n\n\n",l)
                break

        counter=0
        i=0
        #написати функцію під ці 2 цикла
       
           
        for i in range(number_of_rectangle-len(list_of_rectangle)):
            y_cordinat=randint(-50,0)
            number=randint(0,140)
            if 10<number<35:
                obj=Rectangle_move(0,y_cordinat,2)
                list_of_rectangle.insert(0,obj)
                
            elif 35<number<45:
                x_rectangle= randint(0,400)
                obj=Rectangle_disappear(x_rectangle,y_cordinat)
                list_of_rectangle.insert(0,obj)
            elif 45<number<85:
                x_rectangle= randint(0,400)
                obj=Rectangle_burn(x_rectangle,y_cordinat)
                list_of_rectangle.insert(0,obj)
            else:

                if(list_of_rectangle[i].x_cordinat<340):
                    x_rectangle= randint(0,400)
                else:
                    x_rectangle= randint(0,400)
            
                o=Rectangle(x_rectangle,y_cordinat)
                list_of_rectangle.insert(0,o)
                stat_obj_chance=randint(0,12)
                if(stat_obj_chance==1):
                    static_boost=Boost_device(list_of_rectangle[0],12,15,15,GRAY)
                    list_of_static_device.insert(0,static_boost)
                elif(stat_obj_chance==2):
                    static_boost=Boost_device(list_of_rectangle[0],16,12,35,BLACK)
                    list_of_static_device.insert(0,static_boost)

            #print(Rectangle.count)
            game_score+=12//number_of_rectangle
            #print("new",end="")
            #print(o)
           #print("old",end="")
            #pri nt(list_of_rectangle[0],end="\n\n")
    
    #print(spead)
    if y_prev-Dudle_Jump.person_y_cordinat==0 and Dudle_Jump.person_y_cordinat!=0 :
        Dudle_Jump.alive=False

    pygame.display.update()
    clock.tick(spead)
    
    #print(f"jump mode is {Dudle_Jump.jump_mode}")

    
    
   



   
    
    #print("4")
    #pygame.draw.ellipse(screen, GRAY, (25, 40, 150, 30))
    #pygame.draw.rect(screen, WHITE, (x_rectangle, y_rectangle, 100, 10))
    #pygame.display.update()
    #for i in range(10):

